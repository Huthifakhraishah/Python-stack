from django.apps import AppConfig


class SurvyappConfig(AppConfig):
    name = 'survyapp'
