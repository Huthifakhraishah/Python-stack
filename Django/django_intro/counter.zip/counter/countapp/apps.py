from django.apps import AppConfig


class CountappConfig(AppConfig):
    name = 'countapp'
