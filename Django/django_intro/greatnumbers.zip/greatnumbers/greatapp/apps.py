from django.apps import AppConfig


class GreatappConfig(AppConfig):
    name = 'greatapp'
