from django.apps import AppConfig


class OroappConfig(AppConfig):
    name = 'oroapp'
